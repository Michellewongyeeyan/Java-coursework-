import java.awt.Color;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

public class ColorPublisher {
    private List<ColorSubscriber> subscribers;

    public ColorPublisher() {
        subscribers = new CopyOnWriteArrayList<>();
    }

    public void addSubscriber(ColorSubscriber cs) {
        if (cs != null && !subscribers.contains(cs)) {
            subscribers.add(cs);
        }
    }

    public void publish(Color c) {
        for (ColorSubscriber subscriber : subscribers) {
            subscriber.notifyColorChange(c);
        }
    }
}
