import java.awt.Color;

public interface ColorSubscriber
{
    public void notifyColorChange(Color c);
}