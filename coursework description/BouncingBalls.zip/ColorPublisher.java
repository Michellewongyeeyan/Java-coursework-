// TODO: Add code to this file as necessary
//       to finish the implementation of ColorPublisher.

import java.awt.Color;

public class ColorPublisher
{
    public void addSubscriber(ColorSubscriber cs)
    {
    }
    public void publish(Color c)
    {
    }
}